#ifndef PATH_FOLLOW_HH
#define PATH_FOLLOW_HH

#include "IO/Speed_Controller/CtrlStruct.hh"
#include "math.h"


int path_follow(CtrlStruct *cvs);

#endif