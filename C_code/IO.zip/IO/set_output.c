#include "set_output.h"

void set_output(double value, const char *label)
{
	
}
