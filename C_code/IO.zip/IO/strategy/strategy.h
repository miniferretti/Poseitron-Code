
#ifndef _STRATEGY_GR2_H_
#define _STRATEGY_GR2_H_

#include "CtrlStruct.h"
#include <math.h>
#include "path_follow.hh"

void main_strategy(CtrlStruct *ctrl);
int opponent_detection(CtrStruct *ctrl);


#endif

