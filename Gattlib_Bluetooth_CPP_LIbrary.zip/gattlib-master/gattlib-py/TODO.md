- Add advertisement data

- Add C function to list BLE adapters
- Add indication support
